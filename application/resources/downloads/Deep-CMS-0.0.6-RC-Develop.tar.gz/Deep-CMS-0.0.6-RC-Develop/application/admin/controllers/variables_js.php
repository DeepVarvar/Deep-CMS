<?php



/**
 * admin submodule, javascript variables
 */

class variables_js extends baseController {


    public function index() {


        /**
         * validate referer of possible CSRF attack
         */

        request::validateReferer(app::config()->site->admin_tools_link . ".*", true);


        /**
         * set main output context
         * and disable changes
         */

        view::setOutputContext("html");
        view::lockOutputContext();


        /**
         * get variables
         */

        $c = app::config();
        $variables = array(
            "locale"           => member::getLocale(),
            "admin_tools_link" => $c->site->admin_tools_link
        );


        $locale = array(

          "document_delete_confirm"          => view::$locale->document_delete_confirm,
          "document_tree_expand_collapse"    => view::$locale->document_tree_expand_collapse,
          "edit_now"                         => view::$locale->edit_now,
          "save"                             => view::$locale->save,
          "delete_now"                       => view::$locale->delete_now,
          "replace_now"                      => view::$locale->replace_now,
          "image_upload"                     => view::$locale->image_upload,
          "image_replace"                    => view::$locale->image_replace,
          "make_is_master"                   => view::$locale->make_is_master,
          "document_create_new"              => view::$locale->document_create_new,
          "document_set_as_parent"           => view::$locale->document_set_as_parent,
          "document_tree_show_only_tb"       => view::$locale->document_tree_show_only_tb

        );


        /**
         * assign to view
         */

        view::assign("variables", json_encode($variables));
        view::assign("locale", json_encode($locale));

        request::addHeader("Content-Type: application/x-javascript");
        $this->setProtectedLayout("variables.html");


    }


}



