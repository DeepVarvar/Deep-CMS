


DROP TABLE IF EXISTS users;
CREATE TABLE users (

    id                  BIGINT(20) NOT NULL AUTO_INCREMENT,
    group_id            BIGINT(20) DEFAULT NULL,
    status              INT(1)     NOT NULL DEFAULT '0',
    locale              CHAR(2)    CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    login               CHAR(128)  CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    password            CHAR(128)  CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    email               CHAR(255)  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    hash                CHAR(128)  CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
    last_ip             CHAR(15)   CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '0.0.0.0',
    registration_date   DATETIME   NOT NULL,
    last_visit          DATETIME   NOT NULL,
    about               TEXT       CHARACTER SET utf8 COLLATE utf8_general_ci,
    working_cache       LONGTEXT   CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,

    PRIMARY KEY (id),

    KEY group_id (group_id),
    KEY status   (status),
    KEY hash     (hash)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;

INSERT INTO users
(id, group_id, status, locale, login, password, email, hash, last_ip, registration_date, last_visit, about)
VALUES
(1, 0, 0, '', 'root', 'b41ab98198fdfb9f3620034eeee345d9', 'support@deep-cms.ru', 'ad0b9568e4f83095cb27bea6aca5c458', '127.0.0.1', NOW(), NOW(), '');

UPDATE users SET id = 0 WHERE id = 1;



DROP TABLE IF EXISTS permissions;
CREATE TABLE permissions (

    id     BIGINT(20) NOT NULL AUTO_INCREMENT,
    name   CHAR(255)  CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,

    PRIMARY KEY (id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;

INSERT INTO permissions (id, name) VALUES

    (1, 'admin_access'),
    (2, 'preferences_manage'),
    (3, 'preferences_recalc'),
    (4, 'preferences_reset');



DROP TABLE IF EXISTS group_permissions;
CREATE TABLE group_permissions (

    group_id        BIGINT(20) NOT NULL,
    permission_id   BIGINT(20) NOT NULL

) ENGINE = MyISAM DEFAULT CHARSET = utf8;

INSERT INTO group_permissions (group_id, permission_id) VALUES

    (0, 1),
    (0, 2),
    (0, 3),
    (0, 4);



DROP TABLE IF EXISTS groups;
CREATE TABLE groups (

    id         BIGINT(20) NOT NULL AUTO_INCREMENT,
    priority   BIGINT(20) NOT NULL,
    name       CHAR(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,

    PRIMARY KEY (id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;

INSERT INTO groups (id, priority, name) VALUES (1, 0, 'root');
UPDATE groups SET id = 0 WHERE id = 1;



DROP TABLE IF EXISTS images;
CREATE TABLE images (

    id           BIGINT(20)  NOT NULL AUTO_INCREMENT,
    document_id  BIGINT(20)  NOT NULL,
    is_master    TINYINT(1)  NOT NULL DEFAULT '0',
    name         CHAR(255)     CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,

    PRIMARY KEY (id),

    KEY document_id (document_id),
    KEY is_master   (is_master)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;



DROP TABLE IF EXISTS documents;
CREATE TABLE documents (

    id                  BIGINT(20)  NOT NULL AUTO_INCREMENT,
    parent_id           BIGINT(20)  NOT NULL,
    prototype           BIGINT(20)  NOT NULL,
    c_prototype         BIGINT(20)  NOT NULL,
    props_id            BIGINT(20)  NOT NULL DEFAULT '0',
    is_publish          TINYINT(1)  NOT NULL DEFAULT '0',
    in_sitemap          TINYINT(1)  NOT NULL DEFAULT '0',
    sort                BIGINT(20)  NOT NULL DEFAULT '0',
    page_alias          MEDIUMTEXT  CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    permanent_redirect  MEDIUMTEXT  CHARACTER SET utf8 COLLATE utf8_bin NOT NULL DEFAULT '',
    page_name           CHAR(255)   CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    page_h1             MEDIUMTEXT  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
    page_title          MEDIUMTEXT  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
    meta_keywords       MEDIUMTEXT  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
    meta_description    MEDIUMTEXT  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
    layout              CHAR(255)   CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    author              BIGINT(20)  NOT NULL,
    last_modified       DATETIME    NOT NULL,
    creation_date       DATETIME    NOT NULL,
    change_freq         CHAR(7)     CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
    search_priority     DOUBLE      DEFAULT NULL,

    PRIMARY KEY (id),

    KEY parent_id  (parent_id),
    KEY prototype  (prototype),
    KEY props_id   (props_id),
    KEY is_publish (is_publish),
    KEY in_sitemap (in_sitemap),
    KEY sort       (sort),
    KEY author     (author)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;



DROP TABLE IF EXISTS document_features;
CREATE TABLE document_features (

    document_id    BIGINT(20) NOT NULL,
    feature_id     BIGINT(20) NOT NULL,
    feature_value  MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,

    KEY document_id (document_id),
    KEY feature_id  (feature_id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;



DROP TABLE IF EXISTS features;
CREATE TABLE features (

    id    BIGINT(20) NOT NULL AUTO_INCREMENT,
    name  CHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,

    PRIMARY KEY (id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;



DROP TABLE IF EXISTS prototypes;
CREATE TABLE prototypes (

    id           BIGINT(20) NOT NULL AUTO_INCREMENT,
    sys_name     CHAR(255)  CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    name         CHAR(255)  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    description  MEDIUMTEXT CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT '',

    PRIMARY KEY (id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;

INSERT INTO prototypes (id, sys_name, name, description) VALUES
    (1, 'props_simple_pages', 'Обычные страницы', 'Прототип свойств обычных страниц сайта');



DROP TABLE IF EXISTS field_types;
CREATE TABLE field_types (

    prototype    BIGINT(20) NOT NULL,
    field_type   CHAR(32)   CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    editor       TINYINT(1) NOT NULL DEFAULT '0',
    name         CHAR(255)  CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
    description  CHAR(255)  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    sort         BIGINT(20) NOT NULL DEFAULT '1',

    KEY prototype (prototype),
    KEY sort      (sort)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;

INSERT INTO field_types (prototype, field_type, editor, name, description, sort) VALUES
    (1, 'textarea', '1', 'page_text', 'Содержимое страницы', 1);



DROP TABLE IF EXISTS props_simple_pages;
CREATE TABLE props_simple_pages (

    id         BIGINT(20) NOT NULL AUTO_INCREMENT,
    page_text  LONGTEXT   CHARACTER SET utf8 COLLATE utf8_general_ci,

    PRIMARY KEY (id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;



DROP TABLE IF EXISTS menu;
CREATE TABLE menu (

    id          BIGINT(20) NOT NULL AUTO_INCREMENT,
    parent_id   BIGINT(20) NOT NULL DEFAULT '0',
    name        CHAR(255)  CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,

    PRIMARY KEY (id),

    KEY parent_id (parent_id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;



DROP TABLE IF EXISTS menu_items;
CREATE TABLE menu_items (

    menu_id        BIGINT(20) NOT NULL,
    document_id    BIGINT(20) NOT NULL,

    KEY menu_id     (menu_id),
    KEY document_id (document_id)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;



DELIMITER $$


DROP PROCEDURE IF EXISTS check_parent_candidate$$
CREATE PROCEDURE check_parent_candidate(IN main_id BIGINT(20), IN candidate_parent_id BIGINT(20), OUT status TINYINT(1))

    READS SQL DATA

    BEGIN

        DECLARE i BIGINT(20);
        DECLARE c BIGINT(20);
        DECLARE candidate BIGINT(20);

        DECLARE children CURSOR FOR SELECT id FROM documents WHERE parent_id = main_id;

        SET status = 0;
        SELECT COUNT(1) INTO c FROM documents WHERE parent_id = main_id;

        IF c > 0 THEN

            SET i = 0;
            OPEN children;
            search : WHILE i < c DO

                FETCH children INTO candidate;

                IF candidate = candidate_parent_id THEN
                    SET status = 1;
                    LEAVE search;
                END IF;

                SET i = i + 1;

            END WHILE search;
            CLOSE children;

            IF status = 0 THEN

                SET i = 0;
                OPEN children;
                subsearch : WHILE i < c DO

                FETCH children INTO candidate;

                    CALL check_parent_candidate(candidate, candidate_parent_id, status);
                    IF status = 1 THEN
                        LEAVE subsearch;
                    END IF;

                    SET i = i + 1;

                END WHILE subsearch;
                CLOSE children;

            END IF;

        END IF;

    END$$



DROP PROCEDURE IF EXISTS get_breadcrumbs$$
CREATE PROCEDURE get_breadcrumbs(IN current_id BIGINT(20), show_home TINYINT(1))

    READS SQL DATA

    BEGIN


        DECLARE buff_id BIGINT(20);
        DECLARE buff_parent_id BIGINT(20);

        DECLARE done_search TINYINT(1);
        DECLARE current_depth BIGINT(20);

        SET done_search = 0;
        SET current_depth = 0;
        SET buff_id = NULL;


        CREATE TEMPORARY TABLE IF NOT EXISTS breadcrumbs (id BIGINT(20), depth BIGINT(20)) ENGINE = MEMORY;
        TRUNCATE TABLE breadcrumbs;


        findloop : WHILE done_search = 0 DO


            SELECT id, parent_id INTO buff_id, buff_parent_id FROM documents WHERE id = current_id;


            IF buff_id IS NULL THEN


                IF show_home != 0 THEN

                    SELECT id, parent_id INTO buff_id, buff_parent_id FROM documents WHERE page_alias = '/';
                    IF buff_id IS NOT NULL THEN
                        INSERT INTO breadcrumbs (id, depth) VALUES(buff_id, current_depth);
                    END IF;

                END IF;


                LEAVE findloop;


            END IF;


            INSERT INTO breadcrumbs (id, depth) VALUES(buff_id, current_depth);


            SET current_id = buff_parent_id;
            SET current_depth = current_depth + 1;
            SET buff_id = NULL;


        END WHILE findloop;


        SELECT

            d.id,
            d.parent_id,
            d.page_name,
            d.page_alias

        FROM breadcrumbs b
        INNER JOIN documents d ON (d.id = b.id AND d.is_publish = 1)
        ORDER BY b.depth DESC;


    END$$



DROP PROCEDURE IF EXISTS get_chain_children$$
CREATE PROCEDURE get_chain_children(IN parent_id BIGINT(20), children_prototype BIGINT(20))

    READS SQL DATA

    BEGIN


        DECLARE c BIGINT(20);
        DECLARE done_search TINYINT(1);


        CREATE TEMPORARY TABLE IF NOT EXISTS children (id BIGINT(20)) ENGINE = MEMORY;
        CREATE TEMPORARY TABLE IF NOT EXISTS buffered_children (id BIGINT(20)) ENGINE = MEMORY;
        CREATE TEMPORARY TABLE IF NOT EXISTS executable_children (id BIGINT(20)) ENGINE = MEMORY;

        TRUNCATE TABLE children;
        TRUNCATE TABLE buffered_children;
        TRUNCATE TABLE executable_children;


        INSERT INTO executable_children (id) VALUES (parent_id);
        SET done_search = 0;


        findchildren : WHILE done_search = 0 DO


            INSERT INTO children SELECT id FROM executable_children;


            SELECT COUNT(1) INTO c FROM documents d
                WHERE d.prototype = children_prototype
                    AND d.parent_id IN(SELECT id FROM executable_children);


            IF c = 0 THEN
                LEAVE findchildren;
            END IF;


            INSERT INTO buffered_children SELECT d.id FROM documents d
                WHERE d.prototype = children_prototype
                    AND d.parent_id IN(SELECT id FROM executable_children);


            TRUNCATE TABLE executable_children;
            INSERT INTO executable_children SELECT id FROM buffered_children;
            TRUNCATE buffered_children;


        END WHILE findchildren;


        SELECT id FROM children;


    END$$



DELIMITER ;








