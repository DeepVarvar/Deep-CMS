<?php



/**
 * search module language file
 */

return array(
    "search"  =>  "Поиск по сайту"
);



