<?php



/**
 * mainModule prototype language file
 */

return array(

    "main_module_prototype_name"    =>  "Модуль",
    "main_module_module_not_found"  =>  "Модуль не найден",
    "main_module_module_alias"      =>  "URL модуля",
    "main_module_connected_module"  =>  "Подключить модуль"

);



