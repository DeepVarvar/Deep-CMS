<?php



/**
 * simpleLink prototype language file
 */

return array(

    "simple_link_prototype_name"    =>  "Ссылка",
    "simple_link_page_alias"        =>  "URL (цель ссылки)",
    "simple_link_alias_invalid"     =>  "Некорректный URL (цель ссылки)"

);



