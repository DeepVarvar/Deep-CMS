<?php



/**
 * simplePage prototype language file
 */

return array(

    "simple_page_prototype_name"  =>  "Обычная страница",
    "simple_page_page_text"       =>  "Содержимое страницы"

);



