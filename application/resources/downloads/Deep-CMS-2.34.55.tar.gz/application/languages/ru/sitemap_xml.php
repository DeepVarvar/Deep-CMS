<?php



/**
 * sitemap_xml module language file
 */

return array(
    "sitemap_xml"  =>  "Карта сайта XML-формата"
);



