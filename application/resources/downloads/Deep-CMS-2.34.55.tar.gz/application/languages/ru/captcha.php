<?php



/**
 * captcha module language file
 */

return array(
    "captcha"  =>  "Капча"
);



