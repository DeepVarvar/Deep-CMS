<?php



/**
 * sitemap module language file
 */

return array(
    "sitemap"  =>  "Карта сайта"
);



