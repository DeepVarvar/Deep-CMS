<?php



/**
 * member error exception type
 */

class memberErrorException extends memberException {
    protected $type = "error";
}



