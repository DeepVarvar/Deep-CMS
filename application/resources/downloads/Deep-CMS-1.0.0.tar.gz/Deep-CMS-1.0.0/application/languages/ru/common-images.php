<?php



/**
 * common images language file
 */

return array(


    "image_add_watermark"               =>  "Добавить водяной знак",
    "image_delete_confirm"              =>  "Вы уверены, что хотите удалить это изображение?",
    "image_has_deleted"                 =>  "Изображение удалено",
    "image_not_found"                   =>  "Изображение не найдено",
    "image_middle"                      =>  "Среднее",
    "image_original"                    =>  "Оригинал",
    "image_stretch_if_small"            =>  "Растягивать маленькие",
    "image_thumbnail"                   =>  "Превью",
    "image_to_square"                   =>  "Сделать квадратным",
    "image_upload"                      =>  "Загрузка изображения",
    "image_replace"                     =>  "Замена изображения",
    "upload_image"                      =>  "Загрузить изображение",
    "upload_image_broken_mime"          =>  "Загруженный файл не является изображением",
    "upload_image_file_error"           =>  "Загрузка изображения не удалась",
    "upload_image_single_only"          =>  "Множественная загрузка невозможна"


);



