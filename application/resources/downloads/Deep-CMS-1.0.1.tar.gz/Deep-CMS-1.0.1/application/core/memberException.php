<?php



/**
 * member exception type
 */

class memberException extends systemException {
    protected $type = "member";
}



