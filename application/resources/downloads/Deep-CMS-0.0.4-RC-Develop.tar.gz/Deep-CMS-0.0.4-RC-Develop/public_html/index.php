<?php



/**
 * memory usage and timer
 */

$memory = memory_get_usage();
$timestart = microtime(true);


/**
 * exception details mode,
 * set value: "debug" or somestring for "production" mode
 */

define("EXCEPTION_MODE", "debug");


/**
 * enable/disable errors amd notices
 */

if (EXCEPTION_MODE === "debug") {

    ini_set("display_errors", "On");
    ini_set("html_errors", "On");

    error_reporting(E_ALL | E_STRICT);

} else {

    ini_set("display_errors", "Off");
    ini_set("html_errors", "Off");

    error_reporting(0);

}


/**
 * defined application path
 */

define("PUBLIC_HTML", dirname(__FILE__) . "/");
define("APPLICATION", realpath(PUBLIC_HTML . "../") . "/application/");


/**
 * loading bootstrap
 */

$bootstrap = APPLICATION . "bootstrap.php";
if (!file_exists($bootstrap)) {
    exit("Bootstrap file $bootstrap not found" . PHP_EOL);
}

require_once $bootstrap;



