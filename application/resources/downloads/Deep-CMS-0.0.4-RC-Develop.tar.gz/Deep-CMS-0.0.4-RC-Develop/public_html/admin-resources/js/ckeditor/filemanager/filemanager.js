


var filemanager = {


    bind: function(params) {


        /*params.target;
        params.lang;*/


    }


}



