<?php



/**
 * system error exception type
 */

class systemErrorException extends systemException {
    protected $type = "error";
}



