<?php



/**
 * admin submodule, preferences of site
 */

class preferences extends baseController {


    /**
     * set permissions for this controller
     */

    public function setPermissions() {


        $this->permissions = array(

            array(

                "action"      => null,
                "permission"  => "preferences_manage",
                "description" => view::$locale->permission_preferences_manage

            ),

            array(

                "action"      => "recalculate",
                "permission"  => "preferences_recalc",
                "description" => view::$locale->permission_preferences_recalc

            ),

            array(

                "action"      => "reset",
                "permission"  => "preferences_reset",
                "description" => view::$locale->permission_preferences_reset

            )

        );


    }


    /**
     * view list of all groups
     */

    public function index() {


        /**
         * save preferences,
         * THROW inside, not working more
         */

        if (request::getPostParam("save") !== null) {
            return $this->savePreferences();
        }


        $c = app::config();


        view::assign(
            "themes",
            utils::getAvailableThemes($c->site->theme)
        );

        view::assign(
            "locales",
            utils::getAvailableLocales($c->site->default_locale)
        );

        view::assign("page_title", view::$locale->preferences_global);
        $this->setProtectedLayout("preferences.html");


    }


    /**
     * reset preferences
     */

    public function reset() {


        /**
         * validate referer of possible CSRF attack
         */

        request::validateReferer(app::config()->site->admin_tools_link . "/preferences");


        /**
         * delete main.json.generated file
         */

        unlink(CONFIG . "main.json.generated");
        app::loadConfig();


        /**
         * show redirect message
         */

        $this->redirectMessage(

            SUCCESS_EXCEPTION,
            view::$locale->success,
            view::$locale->preferences_global_is_reseted,
            app::config()->site->admin_tools_link . "/preferences"

        );


    }


    /**
     * recalculate permissions of all controllers
     */

    public function recalculate() {


        /**
         * validate referer of possible CSRF attack
         */

        request::validateReferer(app::config()->site->admin_tools_link . "/preferences");


        /**
         * get all permissions from controllers
         */

        $controllersPermissions = array();
        $controllers = utils::getAllControllers();

        foreach ($controllers as $controller) {


            foreach ($controller->getPermissions() as $current) {

                if (!in_array($current['permission'], $controllersPermissions)) {
                    array_push($controllersPermissions, $current['permission']);
                }

            }


        }


        /**
         * get exists permissions of groups in datatbase
         */

        $groupExistsPermissions = db::query("

            SELECT

                p.id,
                p.name,
                gp.group_id

            FROM permissions p
            INNER JOIN group_permissions gp ON gp.permission_id = p.id

            WHERE p.name IN(%s) AND gp.group_id != 0

            ",

            $controllersPermissions

        );


        /**
         * truncate tables group_permissions and permissions
         */

        db::set("TRUNCATE TABLE group_permissions");
        db::set("TRUNCATE TABLE permissions");


        /**
         * insert new list of permissions
         */

        $permissionValues = "('" . join("'), ('", $controllersPermissions) . "')";

        db::set("
            INSERT INTO permissions (name)
            VALUES {$permissionValues}
        ");


        /**
         * get new list of permissions
         */

        $newPermissions = db::query("SELECT id, name FROM permissions");


        /**
         * build new groups permissions
         */

        $newGroupsPermissions = array();
        foreach ($newPermissions as $permission) {


            /**
             * push new permission for root
             */

            array_push($newGroupsPermissions, "(0,{$permission['id']})");


            /**
             * push for other users
             */

            foreach ($groupExistsPermissions as $groupPermission) {


                if ($permission['name'] == $groupPermission['name']) {

                    array_push(
                        $newGroupsPermissions,
                        "({$groupPermission['group_id']},{$permission['id']})"
                    );

                }


            }

        }


        /**
         * insert new groups permissions
         */

        $newGroupsPermissionsValues = join(", ", $newGroupsPermissions);

        db::set("
            INSERT INTO group_permissions (group_id,permission_id)
            VALUES {$newGroupsPermissionsValues}
        ");


        /**
         * show redirect message
         */

        $this->redirectMessage(

            SUCCESS_EXCEPTION,
            view::$locale->success,
            view::$locale->permissions_is_recalculated,
            app::config()->site->admin_tools_link . "/preferences"

        );


    }


    /**
     * save preferences
     */

    private function savePreferences() {


        /**
         * validate referer of possible CSRF attack
         */

        request::validateReferer(app::config()->site->admin_tools_link . "/preferences");


        /**
         * get required data
         */

        $preferences = request::getRequiredPostParams(array("site", "system"));
        if ($preferences === null) {
            throw new memberErrorException(view::$locale->error, view::$locale->data_not_enough);
        }


        /**
         * check required system data
         */

        $requiredSystemData = array(
            "max_group_priority_number",
            "cookie_expires_time"
        );

        foreach ($requiredSystemData as $item) {

            if (!array_key_exists($item, $preferences['system'])) {
                throw new memberErrorException(view::$locale->error, view::$locale->data_not_enough);
            }

        }


        /**
         * check required site data
         */

        $requiredSiteData = array(

            "theme",
            "default_locale",
            "admin_tools_link",
            "default_keywords",
            "default_description"

        );

        foreach ($requiredSiteData as $item) {

            if (!array_key_exists($item, $preferences['site'])) {
                throw new memberErrorException(view::$locale->error, view::$locale->data_not_enough);
            }

        }


        /**
         * validate max_group_priority_number
         */

        if (!utils::isNumber($preferences['system']['max_group_priority_number'])) {
            throw new memberErrorException(view::$locale->error, view::$locale->priority_need_is_number);
        }

        if ($preferences['system']['max_group_priority_number'] > 1000) {
            throw new memberErrorException(view::$locale->error, view::$locale->priority_max_is_1000);
        }


        /**
         * validate cookie_expires_time
         */

        if (!utils::isNumber($preferences['system']['cookie_expires_time'])) {
            throw new memberErrorException(view::$locale->error, view::$locale->cookie_expires_need_is_number);
        }


        /**
         * validate theme (metapackage view templates)
         */

        if (!utils::likeString($preferences['site']['theme'])) {
            throw new memberErrorException(view::$locale->error, view::$locale->data_invalid_format);
        }

        $existsTheme = false;
        foreach (utils::getAvailableThemes() as $theme) {

            if ($theme['value'] == $preferences['site']['theme']) {
                $existsTheme = true;
                break;
            }

        }

        if (!$existsTheme) {
            throw new memberErrorException(view::$locale->error, view::$locale->theme_of_site_not_found);
        }


        /**
         * validate default_locale
         */

        if (!utils::likeString($preferences['site']['default_locale'])) {
            throw new memberErrorException(view::$locale->error, view::$locale->data_invalid_format);
        }

        if (!preg_match("/^[a-z-]+$/", $preferences['site']['default_locale'])) {
            throw new memberErrorException(view::$locale->error, view::$locale->locale_name_need_iso639_std);
        }

        $existsLocale = false;
        foreach (utils::getAvailableLocales() as $locale) {

            if ($locale['value'] == $preferences['site']['default_locale']) {
                $existsLocale = true;
                break;
            }

        }

        if (!$existsLocale) {
            throw new memberErrorException(view::$locale->error, view::$locale->locale_file_not_found);
        }


        /**
         * validate admin_tools_link
         */

        $adminLinkFilter = filter::input($preferences['site']['admin_tools_link']);
        if (preg_match("/[^a-z0-9\/]/u", $adminLinkFilter->getData())) {
            throw new memberErrorException(view::$locale->error, view::$locale->admin_tools_link_invalid_format);
        }

        $adminLinkFilter->trim("/")->expReplace(array("/\/+/", "/^([^\/])/"), array("", "/$1"));
        $preferences['site']['admin_tools_link'] = $adminLinkFilter->getData();

        if (!$preferences['site']['admin_tools_link']) {
            throw new memberErrorException(view::$locale->error, view::$locale->admin_tools_link_invalid_format);
        }


        /**
         * stored default site keywords
         */

        $preferences['site']['default_keywords']
            = filter::input($preferences['site']['default_keywords'])
                ->textOnly()
                ->getData();


        /**
         * stored default site description
         */

        $preferences['site']['default_description']
            = filter::input($preferences['site']['default_description'])
                ->textOnly()
                ->getData();


        /**
         * update configuration,
         * save config into generated file
         */

        app::changeConfig("main.json", $preferences);
        app::saveConfig("main.json");


        /**
         * reset view locale before redirect,
         * show message for correct new locale
         */

        $newConfig = app::config();
        view::setLocale($newConfig->site->default_locale);


        /**
         * show redirect message
         */

        $this->redirectMessage(

            SUCCESS_EXCEPTION,
            view::$locale->success,
            view::$locale->preferences_global_is_changed,
            $newConfig->site->admin_tools_link . "/preferences"

        );


    }


}



