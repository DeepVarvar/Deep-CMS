<?php



/**
 * sitemap language file
 */

return array(
    "sitemap"                      =>  "Карта сайта"
);



