<?php



/**
 * simple search language file
 */

return array(

    "simple_search_of_site"        =>  "Поиск по сайту",
    "simple_search_placeholder"    =>  "Что ищем?",
    "simple_search_more"           =>  "Подробнее",
    "simple_search_search_now"     =>  "Искать"

);



